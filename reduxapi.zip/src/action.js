import { GET_USERS, SET_LOADING, ERROR_DATA } from './actionTypes';



export const getUsers = (user) =>
  async dispatch => {
    try {
      setLoading();
      console.log(user);
      if (user != null) {
        const result = await fetch("https://api.github.com/users/" + user);
        const data = await result.json();
        console.log(data);
        if (data.message == "Not Found") {
          dispatch({
            type: ERROR_DATA,
          })
        } else {
          dispatch({
            type:GET_USERS,
            preload : data
          })
        }
      }
    }

    catch (error) {
      console.log("error")
      dispatch({
        type: ERROR_DATA,
        preload: error.response.statusText
      })
    }
  }


export const setLoading = () => {
  console.log("loading")
  return {
    type: SET_LOADING
  }
}