export const GET_USERS = 'GET_USERS';
export const SET_LOADING = 'SET_LOADING';
export const ERROR_DATA = 'ERROR_DATA';