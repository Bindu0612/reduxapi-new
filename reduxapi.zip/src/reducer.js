import {GET_USERS, SET_LOADING, ERROR_DATA} from './actionTypes';

const initialState= {
  users : null,
  loading: false, 
    userData: false, 
      errorData: false
}


export default (state = {initialState}, action) =>{
  console.log(action.type)
  switch (action.type){
      
    case SET_LOADING :
      console.log("load")
        return {
            ...state,
            loading : true
        }

    case GET_USERS :
        console.log(action.preload);
          return {
              ...state,
              userData : true,
              users : action.preload,
              loading : false
          }

      case ERROR_DATA:
console.log("ERRORdata")
      return{
          ...state,
          users : null,
          userData :true,
          loading : false
        }

      default :
          return state;                
  }
}
